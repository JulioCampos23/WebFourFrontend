import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ParqueoRoutingModule } from './parqueo-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ParqueoRoutingModule
  ]
})
export class ParqueoModule { }
