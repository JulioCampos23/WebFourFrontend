import { Component } from '@angular/core';

@Component({
  selector: 'app-crear-mensualidad',
  templateUrl: './crear-mensualidad.component.html',
  styleUrls: ['./crear-mensualidad.component.scss']
})
export class CrearMensualidadComponent {

}
