import { Component } from '@angular/core';

@Component({
  selector: 'app-crear-tarifa',
  templateUrl: './crear-tarifa.component.html',
  styleUrls: ['./crear-tarifa.component.scss']
})
export class CrearTarifaComponent {

}
