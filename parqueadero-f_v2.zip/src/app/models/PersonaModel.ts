export class PersonaModel {
    id : string
    documento: string
    nombres : string
    apellidos : string
    telefono : string
    correo : string
    perfil : string
    password : string
}