import { Persona } from './persona_o';

describe('Persona', () => {
  it('should create an instance', () => {
    expect(new Persona()).toBeTruthy();
  });
});
