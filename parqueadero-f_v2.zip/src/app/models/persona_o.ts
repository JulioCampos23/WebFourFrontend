export class Persona {
    
}
