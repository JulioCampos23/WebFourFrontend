export const environment = {
    production: false,
    urlBackend : 'http://localhost:3000',
    tokenName : 'token'
  };
